package org.dstadler.compress.fuzz;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.Collection;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.compressors.CompressorException;
import org.apache.commons.compress.compressors.CompressorInputStream;
import org.apache.commons.compress.compressors.CompressorOutputStream;
import org.apache.commons.compress.compressors.CompressorStreamFactory;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import org.apache.commons.compress.compressors.deflate.DeflateCompressorOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.compress.compressors.lz4.BlockLZ4CompressorOutputStream;
import org.apache.commons.compress.compressors.lz4.FramedLZ4CompressorOutputStream;
import org.apache.commons.compress.compressors.lzma.LZMACompressorOutputStream;
import org.apache.commons.compress.compressors.pack200.Pack200CompressorOutputStream;
import org.apache.commons.compress.compressors.snappy.FramedSnappyCompressorOutputStream;
import org.apache.commons.compress.compressors.snappy.SnappyCompressorOutputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream;
import org.apache.commons.compress.compressors.zstandard.ZstdCompressorOutputStream;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

/**
 * This class provides a simple target for fuzzing Apache Commons Compress with Jazzer.
 *
 * It uses the fuzzed input data to try to detect and unpack archives.
 *
 * It catches all exceptions that are currently expected.
 */
public class Fuzz {
	private static final ArchiveOutputStream[] ARCHIVE_STREAMS = new ArchiveOutputStream[] {
			new CpioArchiveOutputStream(new ByteArrayOutputStream()),
			new TarArchiveOutputStream(new ByteArrayOutputStream()),
			new ArArchiveOutputStream(new ByteArrayOutputStream()),
			new ZipArchiveOutputStream(new ByteArrayOutputStream()),
	};
	private static final CompressorOutputStream[] COMPRESS_STREAMS;
	static {
		try {
			COMPRESS_STREAMS = new CompressorOutputStream[] {
					new FramedSnappyCompressorOutputStream(new ByteArrayOutputStream()),
					new Pack200CompressorOutputStream(new ByteArrayOutputStream()),
					new BZip2CompressorOutputStream(new ByteArrayOutputStream()),
					new FramedLZ4CompressorOutputStream(new ByteArrayOutputStream()),
					new XZCompressorOutputStream(new ByteArrayOutputStream()),
					new DeflateCompressorOutputStream(new ByteArrayOutputStream()),
					new BlockLZ4CompressorOutputStream(new ByteArrayOutputStream()),
					new GzipCompressorOutputStream(new ByteArrayOutputStream()),
					new SnappyCompressorOutputStream(new ByteArrayOutputStream(), 1000),
					new LZMACompressorOutputStream(new ByteArrayOutputStream()),
					new ZstdCompressorOutputStream(new ByteArrayOutputStream()),
			};
		} catch (IOException e) {
			throw new IllegalStateException(e);
		}
	}

	public static void fuzzerTestOneInput(byte[] inputData) {
		// try to invoke various methods which read archive data
		try {
			ArchiveInputStream input = new ArchiveStreamFactory()
					.createArchiveInputStream(new ByteArrayInputStream(inputData));

			while(true) {
				ArchiveEntry nextEntry = input.getNextEntry();
				if (nextEntry == null) {
					break;
				}
			}

			Collection<File> filesToArchive = FileUtils.listFiles(new File("src"), TrueFileFilter.TRUE, TrueFileFilter.TRUE);

			for (ArchiveOutputStream out : ARCHIVE_STREAMS) {
				for (File f : filesToArchive) {
					ArchiveEntry entry = out.createArchiveEntry(f, f.getName());
					out.putArchiveEntry(entry);
					try (InputStream i = Files.newInputStream(f.toPath())) {
						IOUtils.copy(i, out);
					}
					out.closeArchiveEntry();
				}
				out.finish();
			}
		} catch (ArchiveException | IOException |
				// many runtime-exceptions are
				// thrown with corrupt files
				RuntimeException e) {
			// expected here
		}

		try {
			CompressorInputStream input = new CompressorStreamFactory(false,
						// enable safety feature which limits how much memory can be allocated
						1024)
					.createCompressorInputStream(new ByteArrayInputStream(inputData));

			ByteArrayOutputStream bytesIn = new ByteArrayOutputStream();
			// read the input stream
			byte[] bytes = new byte[1024];
			while (true) {
				int read = input.read(bytes);
				if (read < 0) {
					break;
				}
				bytesIn.writeBytes(bytes);
			}

			for (CompressorOutputStream stream : COMPRESS_STREAMS) {
				stream.write(bytesIn.toByteArray());
			}
		} catch (CompressorException | IOException |
				// many runtime-exceptions are
				// thrown with corrupt files
				RuntimeException e) {
			// expected here
		} catch (Error e) {
			// only allow "Error" directly, none of the derived classes
			if (!e.getClass().getSimpleName().equals("Error")) {
				throw e;
			}
		}
	}
}
